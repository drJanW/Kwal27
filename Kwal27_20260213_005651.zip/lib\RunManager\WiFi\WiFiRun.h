/**
 * @file WiFiRun.h
 * @brief WiFi connection state management
 * @version 260201A
 $12026-02-05
 */
#pragma once

#include <Arduino.h>

class WiFiRun {
public:
    void plan();
};

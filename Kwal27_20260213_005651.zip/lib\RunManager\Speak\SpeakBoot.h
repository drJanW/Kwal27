/**
 * @file SpeakBoot.h
 * @brief TTS speech one-time initialization
 * @version 260131A
 $12026-02-05
 */
#pragma once

class SpeakBoot {
public:
    void plan();
};

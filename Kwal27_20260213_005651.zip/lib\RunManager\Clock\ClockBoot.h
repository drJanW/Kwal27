/**
 * @file ClockBoot.h
 * @brief RTC/NTP clock one-time initialization
 * @version 260131A
 $12026-02-05
 */
#pragma once

class ClockBoot {
public:
    void plan();
};

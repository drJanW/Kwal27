#pragma once

/**
 * @file ContextFlags.h
 * @brief ContextFlags implementation
 * @version 260202A
 $12026-02-05
 */
#include "StatusFlags.h"

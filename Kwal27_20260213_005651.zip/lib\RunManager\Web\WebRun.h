/**
 * @file WebRun.h
 * @brief Web interface state management
 * @version 260201A
 $12026-02-05
 */
#pragma once

#include <Arduino.h>

class WebRun {
public:
    void plan();
};

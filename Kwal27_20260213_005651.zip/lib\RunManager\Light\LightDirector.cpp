/**
 * @file LightDirector.cpp
 * @brief LED show selection logic implementation
 * @version 260131A
 $12026-02-06
 */
#include "LightDirector.h"

#include "Globals.h"

void LightDirector::plan() {//TODO: move light orchestration here
    PL_BOOT("[Run][Plan] TODO: move light orchestration here");
}

/**
 * @file BH1750.cpp
 * @brief Ambient light sensor driver implementation
 * @version 260202A
 $12026-02-05
 */
#include "BH1750.h"
// All inline in header for minimal footprint.

Start-Process cmd.exe -ArgumentList '/k "C:\Windows\Sysnative\OpenSSH\ssh.exe sshd@192.168.2.23"'

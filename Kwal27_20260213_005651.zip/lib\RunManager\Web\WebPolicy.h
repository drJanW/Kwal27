/**
 * @file WebPolicy.h
 * @brief Web interface business logic
 * @version 260201A
 $12026-02-05
 */
#pragma once

namespace WebPolicy {

    void configure();
}

#pragma once

/**
 * @file LightPatterns.h
 * @brief LightPatterns implementation
 * @version 260202A
 $12026-02-05
 */
#include "LightPatternCatalog.h"

/**
 * @file WiFiPolicy.h
 * @brief WiFi connection business logic
 * @version 260201A
 $12026-02-05
 */
#pragma once

namespace WiFiPolicy {

    void configure();
}

/**
 * @file LightBoot.h
 * @brief LED show one-time initialization
 * @version 260131A
 $12026-02-05
 */
#pragma once

class LightBoot {
public:
    void plan();
};

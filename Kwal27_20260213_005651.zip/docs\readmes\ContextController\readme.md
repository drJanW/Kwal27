# ContextController

> Version: 260205D | Updated: 2026-02-05

The runtime brain of the system: gathers state from the environment, normalizes it, and surfaces "what's happening now" to the rest of the system. Timer-driven updates and sensor snapshots all feed into that shared context.

## Key Components

- **Calendar**: Calendar CSV parsing and theme lookup
- **CalendarSelector**: Scheduled calendar selection
- **StatusFlags**: System-wide boolean flags
- **LightColors/LightPatterns**: LED show configuration
- **ThemeBoxTable**: Theme box audio/visual mapping
- **TimeOfDay**: Time-based context (dawn, day, dusk, night)
- **TodayState**: Daily state snapshot

